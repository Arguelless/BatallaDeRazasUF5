import windows.Starting_Window;

public class main {

	public static void main(String[] args) {
		new Starting_Window();

	}

}
